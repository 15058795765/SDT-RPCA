function psnr_vals = compute_psnr(X, L, maxP)


d = ndims(X);
sz = size(X);
num_samples = sz(end);

psnr_vals = zeros(1, num_samples);

for p = 1:num_samples
    idx = repmat({':'}, 1, d);
    idx{end} = p;
    
    Xora = X(idx{:});
    Lhat = L(idx{:});
    
    psnr_vals(p) = PSNR(Xora, Lhat, maxP);
end

end