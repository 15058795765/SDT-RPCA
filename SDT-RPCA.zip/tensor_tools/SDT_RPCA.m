function [L, psnr_vals, info] = SDT_RPCA(X, Xn)

opts = [];
d = ndims(X);
Nway = size(X);
maxP = max(X(:));


base_lambda = 1 / sqrt(prod(Nway) / min(Nway(1), Nway(2)));
opts.lambda = 1.2 * base_lambda;
opts.mu   = 1e-4;
opts.beta = 1e-4;
opts.rho  = 1.05;
opts.rho2 = 1.05;
opts.detail = 1;

if d == 3
    opts.directions = [1,2];
    opts.direU = [3];
elseif d == 4
    opts.directions = [1,2,3];
    opts.direU = [4];
else
    error('error');
end

[L, E, obj, err, iter] = UTL_TCTV_ADMM(Xn, opts);

psnr_vals = compute_psnr(X, L, maxP);

info.E    = E;
info.obj  = obj;
info.err  = err;
info.iter = iter;
info.size = Nway;
info.ndims = d;

end