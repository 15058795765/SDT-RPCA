clear all;clc;

method={'SDT_RPCA'};%
BGU_list_Face = {'yaleB01_O','yaleB04_O','yaleB20_O','yaleB01_R','yaleB04_R','yaleB20_R'};;
BGU_list_Video = {'bus_O','mobile_O','tempete_O','BLACK_HAWK_DOWN_run_f_cm_np1_le_med_O',...
    'Catch_Me_If_You_Can_run_u_cm_np1_le_med_O','likebeckam_run_f_cm_np1_fr_med_O',...
    'The_Matrix_6_run_f_cm_np1_ba_med_O','bus_R','mobile_R','tempete_R',...
    'BLACK_HAWK_DOWN_run_f_cm_np1_le_med_R','Catch_Me_If_You_Can_run_u_cm_np1_le_med_R',...
    'likebeckam_run_f_cm_np1_fr_med_R','The_Matrix_6_run_f_cm_np1_ba_med_R'};
BGU_list = [ BGU_list_Face, BGU_list_Video];
% c = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30];
c = [ 0.10, 0.20,  0.30];
for num_m=1:length(method)
    for video_num=1:length(BGU_list)
        S = load([BGU_list{video_num}, '.mat']);
        if isfield(S, 'data')
            Y = S.data;
        elseif isfield(S, 'Rdata')
            Y = S.Rdata;
        else
            error('error', file_path);
        end
        maxP=max(Y(:));
        if maxP > 0
            Y = Y / maxP;
        end
        
        dim=size(Y);
        d = ndims(Y);
        fprintf('Processing %s, ndims = %d, size = [', BGU_list{video_num}, d);
        fprintf('%d ', dim);
        fprintf(']\n');
        for j=1:length(c)
            X0=Y;
            S0=zeros(dim);
            
            randmind = randperm(prod(dim));
            num_noise = floor(prod(dim) * c(j));
            S0(randmind(1:num_noise)) = rand(num_noise, 1);
            noisedX = X0 + S0;
            
            funcc=str2func (method{num_m});
            [L, psnr_vals, info] = funcc(Y, noisedX);
            Mpsnr = mean(psnr_vals);
            
            
            current_folder = fileparts(mfilename('fullpath'));
            pathname = fullfile(current_folder, 'result');
            Path = fullfile(pathname, method{num_m},'\');
            if ~exist(Path, 'dir')
                mkdir(Path);
            end
            filename=[method{num_m} '_' BGU_list{video_num} '_' mat2str(c(j)) '.mat'];
            save(strcat(Path,filename),'Mpsnr','L');
            fprintf('  noise = %.2f, mean PSNR = %.4f\n', c(j), Mpsnr);
        end
    end
end

