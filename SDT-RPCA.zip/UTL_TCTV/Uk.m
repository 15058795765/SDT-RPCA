function UkY=Uk(Y,Uk,k) 
dim=size(Y);
Yk=Unfold(Y,dim,k);
UkYk=Uk*Yk;
UkY=folds(UkYk,dim,k); 