function Fig_EnlargeArea(X,Earea_loc,show_loc,lengthline)

h=Earea_loc(2)-Earea_loc(1)+1;
w=Earea_loc(4)-Earea_loc(3)+1;
subX=zeros(h+2*lengthline,w+2*lengthline);
subX(1+lengthline:lengthline+h,1+lengthline:lengthline+w)=X(Earea_loc(1):Earea_loc(2),Earea_loc(3):Earea_loc(4));
h1 = axes('position', [0.0 0.0 1.0 1.0], 'parent', gcf);
imshow(uint8(X),'parent',h1) 
h2 = axes('position', show_loc, 'parent', gcf);
 axes(h2); 
 imshow(uint8(subX),'parent',h2);