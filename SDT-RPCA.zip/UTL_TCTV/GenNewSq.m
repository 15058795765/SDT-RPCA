function [NewSq,invNewSq]=GenNewSq(length,mode)
switch mode
    case  'iden'
      NewSq=[1:length];
    [~,invNewSq]=sort(NewSq);
    case 'color_randomly'
    %only for rgb data
    subSq=randperm(length/3);
   NewSq= zeros(1,length);
    for i = 1:(length/3)
   NewSq(((i-1)*3+1):i*3)=((subSq(i)-1)*3+1):subSq(i)*3;
    end
   [~,invNewSq]=sort(NewSq);
   case 'randomly'
    NewSq=randperm(length);
    [~,invNewSq]=sort(NewSq);
end
end