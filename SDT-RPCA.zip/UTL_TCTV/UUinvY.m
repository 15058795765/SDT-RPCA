function UinvY=UUinvY(Y,P,direU)
n=length(direU);
dim=size(Y);
UinvY=Y;
for k=n:-1:1
UinvYk=Unfold(UinvY,dim,direU(k));
UinvYk=P{direU(k)}'*UinvYk;
UinvY=folds(UinvYk,dim,direU(k));
end