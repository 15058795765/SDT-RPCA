function UY=UUY(Y,Q,direU)
n=length(direU);
dim=size(Y);
UY=Y;
for k=1:n
UYk=Unfold(UY,dim,direU(k));
UYk=Q{direU(k)}*UYk;
UY=folds(UYk,dim,direU(k));
end