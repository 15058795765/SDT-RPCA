function newQ=UpdateQ(temp,P,Q,direU)
dim=size(P);
% Update Q
    newQ=Q; 
    d=length(direU);
    for k=1:d
        P0=P;
        array=[1:d];
        array(k)=[]; 
        for i=array
            Pk=Unfold(P0,dim,direU(i));
            Pk=newQ{direU(i)}*Pk;
            P0=folds(Pk,dim,direU(i));
        end
        Pk=Unfold(P0,dim,direU(k));
        tempk=Unfold(temp,dim,direU(k));
        inMatrix=tempk*Pk';
        [U,S,V]=svd(inMatrix);
        newQ{direU(k)}=U*V';
    end