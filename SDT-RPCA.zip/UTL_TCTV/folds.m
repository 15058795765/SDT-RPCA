% function foldY=folds(unfoldY,mode,shapeY)
% 
% if mode==3
%     [n3,m]=size(unfoldY);
%     foldY=zeros([shapeY(1),shapeY(2),n3]);
%     for i=1:n3
%         foldY(:,:,i)=reshape(unfoldY(i,:),shapeY(1),shapeY(2));
%     end
% end


function X=folds(unfoldY,dim,mode)
n=length(dim);
array=1:n;
array=[array(mode:n) array(1:mode-1)];
X = reshape(unfoldY, dim(array));
X=shiftdim(X,1-mode+n);
X=squeeze(X);


% shape2=shapeY;
% shape2(mode)=[];
% oldY=reshape(unfoldY,[shapeY(mode) shape2]);
% n=length(shapeY);
% array=1:n;
% array(mode)=[];
% array=[mode array];
%   [~,invarray]=sort(array);
% Y=permute(oldY,invarray);
% if mode==3
%     [n3,m]=size(unfoldY);
%     oldY=zeros(shapeY);
%     for i=1:n3
%         oldY(:,:,i)=reshape(unfoldY(i,:),shape2);
%     end
% end