function psnr = PSNR_HighOrder(Xfull,Xrecover,maxP)


Xrecover = max(0,Xrecover);
Xrecover = min(maxP,Xrecover);
dim = size(Xrecover);
MSE = norm(Xfull(:)-Xrecover(:))^2/prod(dim);
psnr = 10*log10(maxP^2/MSE);