function X = PCA_hard(Y,transform,tol)

 
k=tol.rank;
[n1,n2,n3] = size(Y);
if nargin == 3
    if transform.l < 0
        error("property L'*L=L*L'=l*I does not holds for some l>0.");
    end
else    
    % fft is the default transform
    transform.L = @fft; transform.l = n3; transform.inverseL = @ifft;
end

X = zeros(n1,n2,n3);
tnn = 0;
if isequal(transform.L,@fft)
    % efficient computing for fft transform
    Y = fft(Y,[],3);    
    % first frontal slice
    [U,S,V] = svd(Y(:,:,1),'econ');
    S = diag(S);
    %r = length(find(S>rho));
    if k >= 1
        %S = S(1:k)-rho;
        X(:,:,1) = U(:,1:k)*diag(S(1:k))*V(:,1:k)';
    end
    tnn = tnn+sum(S);
    % i=2,...,halfn3
    halfn3 = round(n3/2);
    for i = 2 : halfn3
        [U,S,V] = svd(Y(:,:,i),'econ');
        S = diag(S);
        %r = length(find(S>rho));
        if k >= 1
            %S = S(1:k)-rho;
            X(:,:,i) = U(:,1:k)*diag(S(1:k))*V(:,1:k)';
        end
        X(:,:,n3+2-i) = conj(X(:,:,i));
        tnn = tnn+sum(S)*2;
    end
    % if n3 is even
    if mod(n3,2) == 0
        i = halfn3+1;
        [U,S,V] = svd(Y(:,:,i),'econ');
        S = diag(S);
        %r = length(find(S>rho));
        if k >= 1
            %S = S(1:k)-rho;
            X(:,:,i) = U(:,1:k)*diag(S(1:k))*V(:,1:k)';
        end
        tnn = tnn+sum(S);
    end
    tnn = tnn/n3;
    X = ifft(X,[],3);
else
    % other transform
    Y = lineartransform(Y,transform);
    for i = 1 : n3
        [U,S,V] = svd(Y(:,:,i),'econ');
        S = diag(S);
        %r = length(find(S>rho));
        if k >= 1
           % S = S(1:r)-rho;
            X(:,:,i) = U(:,1:k)*diag(S(1:k))*V(:,1:k)';
            tnn = tnn+sum(S);
        end
    end
    tnn = tnn/transform.l;
    X = inverselineartransform(X,transform);
end